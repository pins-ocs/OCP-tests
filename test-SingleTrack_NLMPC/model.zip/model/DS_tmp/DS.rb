class COMMON_Build
  DATA = {
    #--------------------------
    :language               => 'C++',
    #--------------------------
    :numEquations           => 12,
    :numStates              => 12,
    :numAlgebraicStates     => 0,
    :numControls            => 2,
    :steady_state_tolerance => 1e-08,
    :steady_state_max_iter  => 300,
    #--------------------------
    :max_iter               => 100,
    :max_step_iter          => 20,
    :max_accumulated_iter   => 500,
    :tolerance              => 1e-08,
    #--------------------------
    :range_step             => 0.01,
    :range_start            => 0,
    :range_end              => 30,

    :states                        => [
      "s",
      "n",
      "xi",
      "u",
      "v",
      "Omega",
      "alpha__r",
      "alpha__f",
      "fzr",
      "fzf",
      "delta",
      "S",
    ],
    :controls                      => [ "delta__o", "S__o" ],
    :algebraicStates               => [],
    :ds_parameters                 => [
      "BYf",
      "BYr",
      "CYf",
      "CYr",
      "DYf",
      "DYr",
      "Izz",
      "Lf",
      "Lr",
      "g",
      "h",
      "kS",
      "kv",
      "m",
      "mu__xf",
      "mu__xr",
      "tau__H",
      "tau__N",
      "sigma__yf",
      "sigma__yr",
    ],
    :post_processing_name          => [
      "fyr",
      "fyf",
      "fxr",
      "fxf",
      "VG",
      "trj_curv",
      "ref_curv",
      "ref_speed",
      "ref_yaw_rate",
      "ref_delta",
      "ref_thrust",
    ],
    :post_processing_parameters    => [],
    :initial_conditions_parameters => [ "V0" ],
    :steady_state_parameters       => [ "Omega0" ],
    :closed_loop_parameters        => [ "KF", "KP", "KU" ],
    :user_function_parameters      => [],
    :constraint_parameters         => [],
    :ModelParameters => [
      {
        :C_value => "0.886e1",
        :value   => "8.86",
        :name    => "BYf",
      },
      {
        :C_value => "0.70e1",
        :value   => "7",
        :name    => "BYr",
      },
      {
        :C_value => "0.17e1",
        :value   => "1.7",
        :name    => "CYf",
      },
      {
        :C_value => "0.17e1",
        :value   => "1.7",
        :name    => "CYr",
      },
      {
        :C_value => "DYf",
        :value   => "DYf",
        :name    => "DYf",
      },
      {
        :C_value => "DYr",
        :value   => "DYr",
        :name    => "DYr",
      },
      {
        :C_value => "3900",
        :value   => "3900",
        :name    => "Izz",
      },
      {
        :C_value => "-15",
        :value   => "-15",
        :name    => "KF",
      },
      {
        :C_value => "0.5e0",
        :value   => "0.5",
        :name    => "KP",
      },
      {
        :C_value => "10",
        :value   => "10",
        :name    => "KU",
      },
      {
        :C_value => "0.13e1",
        :value   => "1.3",
        :name    => "Lf",
      },
      {
        :C_value => "0.15e1",
        :value   => "1.5",
        :name    => "Lr",
      },
      {
        :C_value => "0",
        :value   => "0",
        :name    => "Omega0",
      },
      {
        :C_value => "10",
        :value   => "10",
        :name    => "V0",
      },
      {
        :C_value => "0.982e1",
        :value   => "9.82",
        :name    => "g",
      },
      {
        :C_value => "0.5e0",
        :value   => "0.5",
        :name    => "h",
      },
      {
        :C_value => "0.4e0",
        :value   => "0.4",
        :name    => "kS",
      },
      {
        :C_value => "0",
        :value   => "0",
        :name    => "kv",
      },
      {
        :C_value => "2100",
        :value   => "2100",
        :name    => "m",
      },
      {
        :C_value => "0.120e1",
        :value   => "1.2",
        :name    => "mu__xf",
      },
      {
        :C_value => "0.120e1",
        :value   => "1.2",
        :name    => "mu__xr",
      },
      {
        :C_value => "0.1e0",
        :value   => "0.1",
        :name    => "tau__H",
      },
      {
        :C_value => "0.1e0",
        :value   => "0.1",
        :name    => "tau__N",
      },
      {
        :C_value => "0.3e0",
        :value   => "0.3",
        :name    => "sigma__yf",
      },
      {
        :C_value => "0.3e0",
        :value   => "0.3",
        :name    => "sigma__yr",
      },
    ],
    :AuxiliaryParameters => [
      {
        :C_value => "0.961e0",
        :value   => "0.961",
        :name    => "mu__yr",
      },
      {
        :C_value => "0.935e0",
        :value   => "0.935",
        :name    => "mu__yf",
      },
      {
        :C_value => "mu__yf",
        :value   => "mu__yf",
        :name    => "DYf",
      },
      {
        :C_value => "mu__yr",
        :value   => "mu__yr",
        :name    => "DYr",
      },
    ],
    :UserFunctions => [],
    :UserMapFunctions => [
      {
        :par_h => "0.01",
        :func => "posPart",
        :class => "PositivePartRegularizedWithErf",
        :args => [ "x" ],
        :namepars => [ "h" ],
      },
      {
        :par_h => "0.01",
        :func => "negPart",
        :class => "NegativePartRegularizedWithErf",
        :args => [ "x" ],
        :namepars => [ "h" ],
      },
    ],
    :UserFunctionsClassInstances => [
      {
        :is_mesh_object => "false",
        :namespace => "SplinesLoad",
        :class => "Mechatronix#SplineSet",
        :instance => "*pSplineRefMan",
        :setup_file => "../model/spline_set_ref_man_data.rb",
        :header => "#include <MechatronixCore/Splines.hh>",
        :mapped => [
          {
            :parameters => [ "curv_trj" ],
            :func => "Curv",
            :pos => "1",
            :derivatives => "3",
            :method => "eval",
            :nargs => "1",
          },
          {
            :parameters => [ "u" ],
            :func => "u_ref",
            :pos => "1",
            :derivatives => "3",
            :method => "eval",
            :nargs => "1",
          },
          {
            :parameters => [ "Omega" ],
            :func => "omega_ref",
            :pos => "1",
            :derivatives => "3",
            :method => "eval",
            :nargs => "1",
          },
          {
            :parameters => [ "delta" ],
            :func => "delta_ref",
            :pos => "1",
            :derivatives => "3",
            :method => "eval",
            :nargs => "1",
          },
          {
            :parameters => [ "S" ],
            :func => "S_ref",
            :pos => "1",
            :derivatives => "3",
            :method => "eval",
            :nargs => "1",
          },
        ],
      },
    ],
    :Constraint1D  => [],
    :Constraint2D  => [],
    :ConstraintU  => [],

    #--------------------------(DEFINES)
    :defines => [
      "#define S_ref_DD(__t1) pSplineRefMan___arrow___eval_DD( __t1,\"S\")",
      "#define S_ref_D(__t1) pSplineRefMan___arrow___eval_D( __t1,\"S\")",
      "#define S_ref(__t1) pSplineRefMan___arrow___eval( __t1,\"S\")",
      "#define delta_ref_DD(__t1) pSplineRefMan___arrow___eval_DD( __t1,\"delta\")",
      "#define delta_ref_D(__t1) pSplineRefMan___arrow___eval_D( __t1,\"delta\")",
      "#define delta_ref(__t1) pSplineRefMan___arrow___eval( __t1,\"delta\")",
      "#define omega_ref_DD(__t1) pSplineRefMan___arrow___eval_DD( __t1,\"Omega\")",
      "#define omega_ref_D(__t1) pSplineRefMan___arrow___eval_D( __t1,\"Omega\")",
      "#define omega_ref(__t1) pSplineRefMan___arrow___eval( __t1,\"Omega\")",
      "#define u_ref_DD(__t1) pSplineRefMan___arrow___eval_DD( __t1,\"u\")",
      "#define u_ref_D(__t1) pSplineRefMan___arrow___eval_D( __t1,\"u\")",
      "#define u_ref(__t1) pSplineRefMan___arrow___eval( __t1,\"u\")",
      "#define Curv_DD(__t1) pSplineRefMan___arrow___eval_DD( __t1,\"curv_trj\")",
      "#define Curv_D(__t1) pSplineRefMan___arrow___eval_D( __t1,\"curv_trj\")",
      "#define Curv(__t1) pSplineRefMan___arrow___eval( __t1,\"curv_trj\")",
      "#define negPart_DD(__t1) negPart.DD( __t1)",
      "#define negPart_D(__t1) negPart.D( __t1)",
      "#define posPart_DD(__t1) posPart.DD( __t1)",
      "#define posPart_D(__t1) posPart.D( __t1)",
    ],
    :rhs_n_eqns => 12,
    :steady_state_equations_n_eqns => 14,
    :steady_state_x_guess_n_eqns => 12,
    :steady_state_u_guess_n_eqns => 2,
    :initial_conditions_n_eqns => 12,
    :post_processing_n_eqns => 11,
    :closed_loop_n_eqns => 2,

    :A => {
      :n_rows  => 12,
      :n_cols  => 12,
      :nnz     => 13,
      :pattern => [
        [  0,   0], [  1,   1], [  2,   0], [  2,   2], [  3,   3], [  4,   4],
        [  5,   5], [  6,   6], [  7,   7], [  8,   8], [  9,   9], [ 10,  10],
        [ 11,  11],
      ],
    },


    :steady_state_DequationsDz => {
      :n_rows  => 14,
      :n_cols  => 14,
      :nnz     => 43,
      :pattern => [
        [  0,   0], [  1,   1], [  2,   2], [  3,   3], [  3,   4], [  3,   5],
        [  3,   7], [  3,   9], [  3,  10], [  3,  11], [  4,   3], [  4,   5],
        [  4,   6], [  4,   7], [  4,   8], [  4,   9], [  4,  10], [  4,  11],
        [  5,   6], [  5,   7], [  5,   8], [  5,   9], [  5,  10], [  5,  11],
        [  6,   3], [  6,   4], [  6,   5], [  6,   6], [  7,   3], [  7,   4],
        [  7,   5], [  7,   7], [  7,  10], [  8,   8], [  8,  11], [  9,   9],
        [  9,  11], [ 10,  10], [ 10,  12], [ 11,  11], [ 11,  13], [ 12,   3],
        [ 13,   5],
      ],
    },


    :Dclosed_loopDx => {
      :n_rows  => 2,
      :n_cols  => 12,
      :nnz     => 5,
      :pattern => [
        [  0,   0], [  0,   1], [  0,   3], [  0,   5], [  1,   3],
      ],
    },


    :DAlambdaDx => {
      :n_rows  => 12,
      :n_cols  => 12,
      :nnz     => 3,
      :pattern => [
        [  0,   0], [  0,   1], [  2,   0],
      ],
    },


    :DrhsDx => {
      :n_rows  => 12,
      :n_cols  => 12,
      :nnz     => 43,
      :pattern => [
        [  0,   2], [  0,   3], [  0,   4], [  1,   2], [  1,   3], [  1,   4],
        [  2,   5], [  3,   3], [  3,   4], [  3,   5], [  3,   7], [  3,   9],
        [  3,  10], [  3,  11], [  4,   3], [  4,   5], [  4,   6], [  4,   7],
        [  4,   8], [  4,   9], [  4,  10], [  4,  11], [  5,   6], [  5,   7],
        [  5,   8], [  5,   9], [  5,  10], [  5,  11], [  6,   3], [  6,   4],
        [  6,   5], [  6,   6], [  7,   3], [  7,   4], [  7,   5], [  7,   7],
        [  7,  10], [  8,   8], [  8,  11], [  9,   9], [  9,  11], [ 10,  10],
        [ 11,  11],
      ],
    },


    :DrhsDu => {
      :n_rows  => 12,
      :n_cols  => 2,
      :nnz     => 2,
      :pattern => [
        [ 10,   0], [ 11,   1],
      ],
    },


  }
end
# end of data file